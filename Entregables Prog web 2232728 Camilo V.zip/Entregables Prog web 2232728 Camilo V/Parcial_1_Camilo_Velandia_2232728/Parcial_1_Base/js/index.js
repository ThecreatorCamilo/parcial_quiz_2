

async function obtenerClima(lat, lon) {
    let url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m&timezone=auto`;
    try {
        let response = await fetch(url);
        if (!response.ok) throw new Error("Error al obtener datos del clima");
        
        let data = await response.json();
        return {
            temperatura: data.current.temperature_2m ,
            humedad: data.current.relative_humidity_2m 
        };
    } catch (error) {
        console.error("Error en obtenerClima:", error);
        return { temperatura: "N/A", humedad: "N/A" };
    }
}

async function obtenerUbicacion(lat, lon) {
    let apiKey = "0oFYnEhHBFfn8bHW5GQvAod486tavB4W";
    let url = `https://api.geocodify.com/v2/reverse?api_key=${apiKey}&lat=${lat}&lng=${lon}`;
    try {
        let response = await fetch(url);
        if (!response.ok) throw new Error("Error en la API de ubicación");

        let data = await response.json();
        if (!data.response || !data.response.features || data.response.features.length === 0) {
            throw new Error("No se encontraron datos de ubicación.");
        }
        let location = data.response.features[0].properties;
        return {
            pais: location.country ,
            region: location.state || location.region ,
            ciudad: location.city || location.county || location.town || location.village || location.hamlet, 
        };
    } catch (error) {
        console.error("Error en obtenerUbicacion:", error);
        return { pais: "Error", region: "Error", ciudad: "Error" };
    }
}

async function obtenerBandera(pais) {
    let url = "https://countriesnow.space/api/v0.1/countries/flag/images";
    try {
        let response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ country: pais })
        });
        if (!response.ok) throw new Error("Error al obtener la bandera");
        let data = await response.json();
        return data.data.flag || "#";
    } catch (error) {
        console.error("Error en obtenerBandera:", error);
        return "#";
    }
}

function actualizarElemento(id, valor) {
    let elemento = document.getElementById(id);
    if (elemento) {
        elemento.textContent = valor;
    }
}

function actualizarHistorial(pais, region, ciudad, lat, lon, temperatura, humedad) {
    let tablaHistorial = document.getElementById("tabla_historial").getElementsByTagName("tbody")[0] || document.createElement("tbody");
    let fila = document.createElement("tr");
    [pais, region, ciudad, lat, lon, temperatura, humedad].forEach(dato => {
        let celda = document.createElement("td");
        celda.textContent = dato;
        fila.appendChild(celda);
    });
    tablaHistorial.appendChild(fila);
    document.getElementById("tabla_historial").appendChild(tablaHistorial);
}

window.addEventListener("load", () => {
    const map = new ol.Map({
        target: "map",
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM(),
            }),
        ],
        view: new ol.View({
            center: ol.proj.fromLonLat([-74.0721, 4.711]),
            zoom: 5,
        }),
    });

    map.on("click", async (event) => {
        const [lon, lat] = ol.proj.toLonLat(event.coordinate);
        try {
            let clima = await obtenerClima(lat, lon);
            let ubicacion = await obtenerUbicacion(lat, lon);
            let banderaUrl = await obtenerBandera(ubicacion.pais);

            actualizarElemento("temperatura", `${clima.temperatura} °C`);
            actualizarElemento("humedad", `${clima.humedad} %`);
            actualizarElemento("pais", ubicacion.pais);
            actualizarElemento("region", ubicacion.region);
            actualizarElemento("ciudad", ubicacion.ciudad);
            actualizarElemento("latitud", lat);
            actualizarElemento("longitud", lon);
            document.getElementById("bandera").src = banderaUrl;

            actualizarHistorial(ubicacion.pais, ubicacion.region, ubicacion.ciudad, lat, lon, clima.temperatura, clima.humedad);
        } catch (error) {
            console.error("Error al obtener datos:", error);
        }
    });
});
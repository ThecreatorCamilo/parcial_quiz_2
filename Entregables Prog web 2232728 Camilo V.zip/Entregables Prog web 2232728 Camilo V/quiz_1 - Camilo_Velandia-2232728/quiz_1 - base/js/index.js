/*
  QUIZ 1 - PROGRAMACIÓN WEB
  Respetado estudiante teniendo en cuenta el proyecto proporcionado deberá desarrollar las siguientes funcionalidades en el sitio web:

  1) Solicitar datos del clima a la API de https://api.open-meteo.com/ usando las coordenadas seleccionadas por el usuario en el mapa. 
  2) Cuando llega la respuesta del servidor, si es correcta mostrar los datos en la tabla correspondiente. 
  3) Desarrollar un historial de busquedas anteriores que vaya cargando en la medida que el usuario selecciona diferentes ubicaciones en el mapa.
*/
let mapa;
let base_url = "https://api.open-meteo.com/v1/forecast?";
let parametros = "&current=temperature_2m,relative_humidity_2m&hourly=temperature_2m";

function mapearDatos(datos, latitud, longitud) {
    document.getElementById("v_lat").innerText = latitud;
    document.getElementById("v_long").innerText = longitud;
    document.getElementById("v_temp").innerText = datos.current.temperature_2m;
    document.getElementById("humedad").innerText = datos.current.relative_humidity_2m;
    actualizarHistorial(latitud, longitud, datos.current.temperature_2m, datos.current.relative_humidity_2m);
}

function cargarDatos(latitud, longitud) {
    let url = `${base_url}latitude=${latitud}&longitude=${longitud}${parametros}`;
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error("Error en la solicitud");
            }
            return response.json();
        })
        .then(data => {
            mapearDatos(data, latitud, longitud);
        })
        .catch(error => {
            console.log("Error:", error);
        });
}

function actualizarHistorial(latitud, longitud, temperatura, humedad) {
    let tabla = document.getElementById("tabla_historial");
    let fila = tabla.insertRow(-1);
    fila.insertCell(0).innerText = latitud;
    fila.insertCell(1).innerText = longitud;
    fila.insertCell(2).innerText = temperatura;
    fila.insertCell(3).innerText = humedad;
}

window.addEventListener("load", function() {
    mapa = new ol.Map({
        target: 'map',
        layers: [
            new ol.layer.Tile({
                source: new ol.source.OSM(),
            }),
        ],
        view: new ol.View({
            center: ol.proj.transform([-72.265911, 3.7644111], 'EPSG:4326', 'EPSG:3857'),
            zoom: 5,
        }),
    });

    mapa.on('click', function(evt) {
        let coordinates = ol.proj.transform(evt.coordinate, 'EPSG:3857', 'EPSG:4326');
        let latitud = coordinates[1].toFixed(6);
        let longitud = coordinates[0].toFixed(6);
        console.log("Latitud:", latitud);
        console.log("Longitud:", longitud);
        cargarDatos(latitud, longitud);
    });
});
